#ifndef HEADER_H
#define HEADER_H
 
void Print(int val); // needed so main.cpp knows that print() is a function declared elsewhere
 
#endif