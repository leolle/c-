#include <iostream>
#include <stdio.h>

void Print(int val)	
{
	printf("the result is %d\n", val * 2);
	return ;
}
