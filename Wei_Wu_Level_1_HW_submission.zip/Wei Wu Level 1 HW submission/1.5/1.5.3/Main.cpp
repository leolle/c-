#include <iostream>
#include <stdio.h>
#include "header.h"


int main()
{
    using namespace std;
	int i = 40;
	Print(i);
    return 0;
}