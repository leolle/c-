#include <stdio.h>
int Fac(int factorNum)	
{

	//int length = factorNum;
	if (factorNum == 1)
	{
		printf("1\n");
		return 1;
	}
	else
	{
		printf("%d * ",factorNum);
		return (Fac(factorNum-1));
	}
}
int main()
{
    using namespace std;
	int num;
	printf("The factorials of 6 is ");
	Fac(6);
	printf("Please enter one number:\n");
	scanf_s("%d",&num);
	printf("The factorials of %d is ", num);
	Fac(num);
    return 0;
}