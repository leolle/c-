#include <iostream>
#include "AmericanOption.hpp"

using namespace std;

AmericanOption::AmericanOption():EuropeanOption()
{

}