#ifndef DEFS_H
#define DEFS_H
#include <stdio.h>
#define PRINT1( x ) printf("a:%d\n", x)
#define PRINT2( x, y) printf("a:%d,b:%d\n", x, y)
#endif