#include "Defs.h"

int main()
{
	int a = 12,b = 2323;
	PRINT1(a);		//using macro to print a
	PRINT2(a , b);	//using macro to print a and b
	return 0;
}