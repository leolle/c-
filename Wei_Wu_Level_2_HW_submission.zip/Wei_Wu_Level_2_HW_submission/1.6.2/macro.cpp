#include "Defs.h"

int main()
{
	int a = 12, b = 2323, c = -23;
	PRINT1(MAX2( a, b));
	PRINT1(MAX3(a, b, c));
	return 0;
}